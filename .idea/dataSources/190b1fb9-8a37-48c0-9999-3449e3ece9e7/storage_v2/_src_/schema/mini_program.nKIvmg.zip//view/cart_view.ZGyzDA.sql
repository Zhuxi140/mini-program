create definer = zhu@`%` view cart_view as
select `c`.`id`                       AS `cart_id`,
       `c`.`user_id`                  AS `user_id`,
       `c`.`product_id`               AS `product_id`,
       `c`.`quantity`                 AS `quantity`,
       `p`.`name`                     AS `product_name`,
       `p`.`price`                    AS `price`,
       `p`.`cover_url`                AS `cover_url`,
       (`p`.`price` * `c`.`quantity`) AS `total_price`
from (`mini_program`.`cart` `c` join `mini_program`.`product` `p` on ((`c`.`product_id` = `p`.`id`)))
where (`p`.`status` = 1);

