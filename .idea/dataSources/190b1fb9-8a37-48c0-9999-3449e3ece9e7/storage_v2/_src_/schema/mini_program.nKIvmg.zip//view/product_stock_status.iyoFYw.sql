create definer = zhu@`%` view product_stock_status as
select `mini_program`.`product`.`id`    AS `id`,
       `mini_program`.`product`.`name`  AS `name`,
       `mini_program`.`product`.`price` AS `price`,
       `mini_program`.`product`.`stock` AS `stock`,
       (case
            when (`mini_program`.`product`.`stock` > 20) then '充足'
            when (`mini_program`.`product`.`stock` between 5 and 20) then '正常'
            when (`mini_program`.`product`.`stock` between 1 and 4) then '紧张'
            else '缺货' end)            AS `stock_status`
from `mini_program`.`product`
where (`mini_program`.`product`.`status` = 1);

-- comment on column product_stock_status.name not supported: 商品名

-- comment on column product_stock_status.price not supported: 价格

-- comment on column product_stock_status.stock not supported: 库存

