create definer = zhu@`%` view cart_view as
select `c`.`id`                       AS `cart_id`,
       `c`.`user_id`                  AS `user_id`,
       `c`.`product_id`               AS `product_id`,
       `c`.`quantity`                 AS `quantity`,
       `p`.`name`                     AS `product_name`,
       `p`.`price`                    AS `price`,
       `p`.`cover_url`                AS `cover_url`,
       (`p`.`price` * `c`.`quantity`) AS `total_price`
from (`mini_program`.`cart` `c` join `mini_program`.`product` `p` on ((`c`.`product_id` = `p`.`id`)))
where (`p`.`status` = 1);

-- comment on column cart_view.quantity not supported: 数量

-- comment on column cart_view.product_name not supported: 商品名

-- comment on column cart_view.price not supported: 价格

-- comment on column cart_view.cover_url not supported: 主图OSS路径

