create definer = zhuxi140@`%` view user_summary as
select `u`.`id`                                               AS `id`,
       coalesce(`u`.`nickname`, `u`.`wx_nickname`)            AS `display_name`,
       coalesce(`u`.`custom_avatar_oss`, `u`.`wx_avatar_url`) AS `avatar`,
       `u`.`phone`                                            AS `phone`,
       `u`.`status`                                           AS `status`,
       count(`o`.`id`)                                        AS `order_count`,
       max(`o`.`created_at`)                                  AS `last_order_time`
from (`mini_program`.`user` `u` left join `mini_program`.`order` `o` on ((`u`.`id` = `o`.`user_id`)))
group by `u`.`id`;

-- comment on column user_summary.id not supported: 用户ID

-- comment on column user_summary.phone not supported: 手机号（唯一）

-- comment on column user_summary.status not supported: 状态：0禁用，1正常

